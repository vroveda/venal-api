# Valor Venal API - Prefeitura SP

API para consultar o valor venal de imóveis cadastrados no site da Prefeitura de São Paulo.

## Como rodar

- Suba para o Render.com como Web Service Node.js
- Build Command: `npm install`
- Start Command: `npm start`
- Node Version: 20